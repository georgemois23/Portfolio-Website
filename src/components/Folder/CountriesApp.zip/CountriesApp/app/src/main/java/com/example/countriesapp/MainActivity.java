package com.example.countriesapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private CountryList countryList;
    private Spinner mySpinner;
    private final String myIP = "192.168.1.10";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        countryList = new CountryList(myIP);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mySpinner = (Spinner) findViewById(R.id.my_spinner);
        Button showButton = (Button) findViewById(R.id.show_button);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                countryList.getAllNames()
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(adapter);

        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selectedName = mySpinner.getSelectedItem().toString();
                Country selected = countryList.getCountryByName(selectedName);

                Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                intent.putExtra("name", selected.getName());
                intent.putExtra("capital", selected.getCapital());
                intent.putExtra("flagUrl", selected.getFlagUrl());
                startActivity(intent);
            }
        });
    }
}