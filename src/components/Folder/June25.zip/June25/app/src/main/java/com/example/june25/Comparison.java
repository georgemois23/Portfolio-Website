package com.example.june25;

public class Comparison {
    private int n1, n2;
    private String image1, image2;

    public Comparison(int n1, int n2, String image1, String image2) {
        this.n1     = n1;
        this.n2     = n2;
        this.image1 = image1;
        this.image2 = image2;
    }

    // Αντίστοιχο getBrandName() — για τον Spinner
    public String getDisplayString() {
        return n1 + "<" + n2;
    }

    // Αντίστοιχο getAllModelsAsString() — για το TextField του 2ου Activity
    public String getResultString() {
        boolean result = n1 < n2;
        return "<<" + n1 + ">> < <<" + n2 + ">> = <<" + result + ">>";
    }

    // Αποφασίζει ποια εικόνα να φορτώσει η Picasso
    // image1 αν ΣΩΣΤΟ (n1<n2), image2 αν ΛΑΘΟΣ
    public String getCorrectImageUrl() {
        return (n1 < n2) ? image1 : image2;
    }
}
