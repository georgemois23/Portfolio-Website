package com.example.june25;

import java.util.ArrayList;
import java.util.List;

    public class ComparisonsList {

    // Ίδια δομή με CarBrandList: ArrayList από αντικείμενα
    ArrayList<Comparison> cList = new ArrayList<>();

    // Constructor — καλεί τον OkHttpHandler (ίδιο με CarBrandList(String ip))
    public ComparisonsList() {
        String url = "http://egov2.dai.uom.gr/chiron/service.php";
        try {
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            cList = okHttpHandler.fetchComparisons(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Αντίστοιχο getAllBrands() — γεμίζει τον Spinner με display strings
    public List<String> getAllDisplayStrings() {
        ArrayList<String> temp = new ArrayList<>();
        for (int i = 0; i < cList.size(); i++) {
            temp.add(cList.get(i).getDisplayString());
        }
        return temp;
    }

    // Βρίσκει το Comparison με βάση το display string (για το NEXT button)
    // Αντίστοιχο getAllModels(String brand)
    public Comparison findByDisplayString(String display) {
        for (int i = 0; i < cList.size(); i++) {
            if (cList.get(i).getDisplayString().equals(display)) {
                return cList.get(i);
            }
        }
        return null;
    }
}