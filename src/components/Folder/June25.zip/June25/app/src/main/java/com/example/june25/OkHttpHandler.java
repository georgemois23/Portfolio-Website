package com.example.june25;

import android.os.StrictMode;
import org.json.JSONArray;
import java.util.ArrayList;
import okhttp3.*;

public class OkHttpHandler {

    public OkHttpHandler() {
        // Ίδιο ακριβώς με CarPicker
        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    // Αντίστοιχο populateDropDown() του CarPicker
    // Εδώ το JSON είναι Array of Arrays: [[n1,n2,"url1","url2"], ...]
    ArrayList<Comparison> fetchComparisons(String url) throws Exception {
        ArrayList<Comparison> list = new ArrayList<>();

        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();

        // Outer array — ολόκληρο το response
        JSONArray outerArray = new JSONArray(data);

        for (int i = 0; i < outerArray.length(); i++) {
            // Inner array — κάθε γραμμή: [n1, n2, image1, image2]
            JSONArray row = outerArray.getJSONArray(i);

            int    n1     = row.getInt(0);
            int    n2     = row.getInt(1);
            String image1 = row.getString(2);
            String image2 = row.getString(3);

            list.add(new Comparison(n1, n2, image1, image2));
        }
        return list;
    }
}