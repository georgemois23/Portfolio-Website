package com.example.june24;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private MultiList ml;
    Spinner mySpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // ⚠️ SOS: Constructor ΠΡΙΝ το super.onCreate() — κάνει network call
        ml = new MultiList();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mySpinner = (Spinner) findViewById(R.id.multis_spinner);

        // Γέμισμα Spinner — ίδιο pattern με CarPicker
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                ml.getAllDisplayStrings()
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(adapter);

        // NEXT Button
        Button nextBtn = (Button) findViewById(R.id.next_button);
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selected = String.valueOf(mySpinner.getSelectedItem());
                Multi m = ml.findByDisplayString(selected);

                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("RESULT_STRING", m.getResultString());
                intent.putExtra("IMAGE_URL",     m.getCorrectImageUrl());
                startActivity(intent);
            }
        });
    }
}