package com.example.countriesapp;

import java.net.URL;

public class Country {
    String name, capital, flagUrl;

    public Country(String name, String capital, String flagUrl){
        this.name = name;
        this.capital = capital;
        this.flagUrl = flagUrl;
    };

    public String getFlagUrl() {
        return flagUrl;
    }

    public String getName() {
        return name;
    }

    public String getCapital() {
        return capital;
    }
}
