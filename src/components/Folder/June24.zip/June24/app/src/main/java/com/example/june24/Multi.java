package com.example.june24;

public class Multi {

    // Πεδία: image1, image2, oper1, oper2, res — όλα String από το JSON
    private String image1, image2, oper1, oper2, res;

    public Multi(String image1, String image2, String oper1, String oper2, String res) {
        this.image1 = image1;
        this.image2 = image2;
        this.oper1  = oper1;
        this.oper2  = oper2;
        this.res    = res;
    }

    // Γεμίζει το Spinner — π.χ. "1*2"
    public String getDisplayString() {
        return oper1 + "*" + oper2;
    }

    // Γεμίζει το TextField του Β Activity
    // Εκφώνηση: "<<oper1>> * <<oper2>> = <<res>>" — π.χ. "1 * 2 = 2"
    public String getResultString() {
        return "<<" + oper1 + ">> * <<" + oper2 + ">> = <<" + res + ">>";
    }

    // ⚠️ SOS: image1 αν ΛΑΘΟΣ, image2 αν ΣΩΣΤΟ (διαβάζουμε ΑΠΟ ΤΗΝ ΕΚΦΩΝΗΣΗ)
    // "image1 αν το αποτέλεσμα είναι ΛΑΘΟΣ, image2 αν ΣΩΣΤΟ"
    public String getCorrectImageUrl() {
        int product  = Integer.parseInt(oper1) * Integer.parseInt(oper2);
        int expected = Integer.parseInt(res);
        return (product == expected) ? image2 : image1;
    }
}
