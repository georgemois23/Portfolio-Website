package com.example.june24;

import android.os.StrictMode;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MultiList {

    ArrayList<Multi> mList = new ArrayList<>();

    // Constructor — ίδιο pattern με CarBrandList(String ip)
    public MultiList() {
        // ⚠️ SOS: StrictMode ΠΡΩΤΑ για network call στο main thread
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        String url = "http://195.251.211.54/a3gg/service.php";
        try {
            OkHttpClient client = new OkHttpClient().newBuilder().build();
            RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
            Request request = new Request.Builder().url(url).method("POST", body).build();
            Response response = client.newCall(request).execute();
            String data = response.body().string();

            // JSON: [[image1, image2, oper1, oper2, res], ...]
            JSONArray outerArray = new JSONArray(data);
            for (int i = 0; i < outerArray.length(); i++) {
                JSONArray row = outerArray.getJSONArray(i);

                String image1 = row.getString(0);  // θέση 0 → image1
                String image2 = row.getString(1);  // θέση 1 → image2
                String oper1  = row.getString(2);  // θέση 2 → oper1
                String oper2  = row.getString(3);  // θέση 3 → oper2
                String res    = row.getString(4);  // θέση 4 → res

                mList.add(new Multi(image1, image2, oper1, oper2, res));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Γεμίζει τον Spinner — επιστρέφει ["1*2", "3*4", ...]
    public List<String> getAllDisplayStrings() {
        ArrayList<String> temp = new ArrayList<>();
        for (int i = 0; i < mList.size(); i++) {
            temp.add(mList.get(i).getDisplayString());
        }
        return temp;
    }

    // Βρίσκει το αντικείμενο από το string του Spinner
    public Multi findByDisplayString(String display) {
        for (int i = 0; i < mList.size(); i++) {
            if (mList.get(i).getDisplayString().equals(display)) {
                return mList.get(i);
            }
        }
        return null;
    }
}