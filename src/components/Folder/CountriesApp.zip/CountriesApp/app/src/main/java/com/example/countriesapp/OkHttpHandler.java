package com.example.countriesapp;

import android.os.StrictMode;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class OkHttpHandler {

    public OkHttpHandler() {
        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    ArrayList<Country> getCountries(String url) throws Exception {
        ArrayList<Country> list = new ArrayList<>();

        OkHttpClient client = new OkHttpClient().newBuilder().build();
        Request request = new Request.Builder().url(url).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();

        try {
            JSONArray jsonArray = new JSONArray(data);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONArray row = jsonArray.getJSONArray(i);
                String name    = row.getString(0);
                String capital = row.getString(1);
                String flagUrl = row.getString(2);
                list.add(new Country(name, capital, flagUrl));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return list;
    }
}