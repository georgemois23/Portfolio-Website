package com.example.june25;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // Ίδιο με CarPicker: private attribute για τη λίστα
    private ComparisonsList cbl;
    Spinner mySpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // ⚠️ ΣΟΣ: Ίδιο με CarPicker — το constructor κάνει network call
        // ΠΡΕΠΕΙ να καλείται ΠΡΙΝ το super.onCreate() και setContentView()
        cbl = new ComparisonsList();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ίδιο με CarPicker — γέμισμα Spinner με ArrayAdapter
        mySpinner = (Spinner) findViewById(R.id.comparisons_spinner);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                cbl.getAllDisplayStrings()
        );
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(arrayAdapter);

        // NEXT Button — στέλνει επιλογή στο 2ο Activity
        Button nextBtn = (Button) findViewById(R.id.next_button);
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Ίδιο με CarPicker's PickCarOnClick — παίρνω επιλογή από Spinner
                String selected = String.valueOf(mySpinner.getSelectedItem());
                Comparison comp = cbl.findByDisplayString(selected);

                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("RESULT_STRING", comp.getResultString());
                intent.putExtra("IMAGE_URL",     comp.getCorrectImageUrl());
                startActivity(intent);
            }
        });
    }
}