package com.example.june25;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import com.squareup.picasso.Picasso;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // Λαμβάνω δεδομένα από MainActivity — ίδιο pattern Intent
        Intent intent = getIntent();
        String resultString = intent.getStringExtra("RESULT_STRING");
        String imageUrl     = intent.getStringExtra("IMAGE_URL");

        // (α) Εμφάνιση αποτελέσματος: "<<1>> < <<2>> = <<true>>"
        TextView resultText = (TextView) findViewById(R.id.result_text);
        resultText.setText(resultString);

        // (β) Φόρτωση εικόνας με Picasso — ίδιο με CarPicker's OkHttp pattern
        ImageView resultImage = (ImageView) findViewById(R.id.result_image);
        resultImage.setVisibility(View.VISIBLE);
        Picasso.get().load(imageUrl).into(resultImage);

        // (γ) BACK Button — finish() επιστρέφει στο 1ο Activity
        Button backBtn = (Button) findViewById(R.id.back_button);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish(); // Ίδιο με CarPicker pattern
            }
        });
    }
}