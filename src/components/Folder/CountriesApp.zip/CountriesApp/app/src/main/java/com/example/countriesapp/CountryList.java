package com.example.countriesapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.*;
import okhttp3.*;

public class CountryList {

    ArrayList<Country> countryList = new ArrayList<>();

    public CountryList(String ip) {
        String url = "http://" + ip + "/countries/getCountries.php";
        try {
            OkHttpHandler handler = new OkHttpHandler();
            countryList = handler.getCountries(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<String> getAllNames() {
        ArrayList<String> names = new ArrayList<>();
        for (int i = 0; i < countryList.size(); i++) {
            names.add(countryList.get(i).getName());
        }
        return names;
    }

    public Country getCountryByName(String name) {
        for (int i = 0; i < countryList.size(); i++) {
            if (countryList.get(i).getName().equals(name)) {
                return countryList.get(i);
            }
        }
        return null;
    }
}