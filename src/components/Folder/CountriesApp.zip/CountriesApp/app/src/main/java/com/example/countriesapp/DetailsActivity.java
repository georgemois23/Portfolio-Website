package com.example.countriesapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        TextView textName = (TextView) findViewById(R.id.text_name);
        TextView textCapital = (TextView) findViewById(R.id.text_capital);
        ImageView imageFlag = (ImageView) findViewById(R.id.image_flag);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String capital = intent.getStringExtra("capital");
        String flagUrl = intent.getStringExtra("flagUrl");

        textName.setText(name);
        textCapital.setText(capital);
        imageFlag.setVisibility(ImageView.VISIBLE);
        Picasso.with(this).load(flagUrl).into(imageFlag);
    }
}